# zjuthesis-proposal

zjuthesis 研究生开题报告模板，原始版本为Zixuan Wang发布的zjuthesis模板v9.0.0，在其基础上修改简化成开题报告模板。原模版地址：https://github.com/TheNetAdmin/zjuthesis。同时参考借鉴了 Shaojian Yang 发布的[zjuthesis-OCproposal](https://github.com/blknaoh/zjuthesis-OCproposal)模板，该模板提供了海洋学院具体的开题报告模板格式。

- Modifier : Haojie Wu

- Email    :   798746557@qq.com

- Update   : https://github.com/blknaoh/zjuthesis-OCproposal

- 当前版本 : v 0.1.1

- 编译环境 ：Windows10 + tex live2021+ Texstudio

- 编译方法 ：一次XeLatex => 一次Bibtex(Biber) => 一次XeLatex

  ​					对应于Texstudio指令为：F6 F8 F6

## Issues in brief :

- 参考文献的路径是./zjuthesis-master-proposal/body/graduate/ref.bib
- 正文是./zjuthesis-master-proposal/body/graduate/content.tex , 建议分章节编辑
- 涉及封面修改，比如中英文标题、密级、分类号等请在./zjuthesis-master-proposal/page/cover-chn.tex中修改